import $ from 'jquery';
import * as bootstrap from "bootstrap";
import { ApiUrl } from '../../index';
import { fnShowLoader, fnHideLoader, fnAlertToast, fnNetworkCheck, fnXhrErrorAlert, fnDTSearchEnable, fnApiStatusFail, fnEmpStatusFail } from '../commonFunction';

var JsonResult=[
    {
     "id": 1,
     "Question": "Welcome To Chatbot",
     "Decription": "This is a Personal Chatbot"
 },
 {
     "id": 2,
     "Question": "Onboarding Employee",
     "Decription": "This is a Onboarding Employee Flow"
 },
 {
     "id": 3,
     "Question": "Onboarding Employee Documents",
     "Decription": "This is a Resigning Employee Flow Documents"
 },
 {
     "id": 4,
     "Question": "Relieving Employee",
     "Decription": "This is a Resigning Employee Flow-1"
 },
 {
     "id": 5,
     "Question": "Relieving Employee Documents",
     "Decription": "This is a Resigning Employee Flow-2"
 }
];


function openForm() {
    document.getElementById("myForm").style.display = "block";
  }
  
  function  closeForm() {
    document.getElementById("myForm").style.display = "none";
  }

  function fnGenerateHistory(UserMsg,Result){
    var ContentStr="";

    ContentStr+='<div class="ChatMsg"><div class="ChatRequest">'
    ContentStr+='<div>You:'+UserMsg+'</div>';
    ContentStr+='</div>';

    $(".ChatHistory").append(ContentStr);

    if(Result.length==0)
        ContentStr='<div  class="ChatMsg"><div class="ChatResponse">Chatbot: There is no information found. Please ask different question.</div></div>';
    else
    {
            ContentStr='<div  class="ChatMsg"><div class="ChatResponse">Chatbot:<ul>';
            //for(var i=0;i<Result.length;i++)
            {
                //ContentStr+='<li><a class="btn-link" data-id="'+Result[0].id +'">'+Result[0].Decription  +'</a></li>';
                ContentStr+='<li>'+Result[0].Decription  +'</li>';
            }
            ContentStr+='</ul>';
            ContentStr+='</div></div>';

    }
    setTimeout(() => {
        $(".ChatHistory").append(ContentStr);

        $('.btn-link').on('click',function()
        {
            var Id=$(this).data('id');
            var Response=JsonResult.fill(t1=>t1.Id==Id);
            $("#ModelQues").html(Response.Question);
            $("#ModalDesc").html(Response.Decription);
            $("#QuestionInfo").modal('show');
        });
    }, 500);
  }
 
  

function fnChatBotInit() 
{
        //  convForm = $('#chat').convform({selectInputStyle: 'disable'});
        //console.log(convForm);

        $('#ChatSend').on('click',function(){

            // $.ajax({
            //         url:'./chatbot/data.html',
            //         method:'get',
            //         dataType:"json",
            //         success:function(response){
            //             console.log(response);
            //         }
            //    });

            
         var msg=$("#msg").val();
            var Result= getObjectByValue(JsonResult,"Question",  msg);
            fnGenerateHistory(msg,Result);
            console.log(Result);$("#msg").val('');

         });

            

        $('#ChatClose').on('click',function(){
            closeForm() ;
        });
        $('#ChatOpen').on('click',function(){
            openForm() ;
        });
        
}

var getObjectByValue = function (array, key, value) {
    return array.filter(function (object) {
        return object[key].toLowerCase().indexOf(value.toLowerCase())>=0;
    });
}

export {
    fnChatBotInit,
    getObjectByValue,
    fnGenerateHistory,
    JsonResult
   
  };
  